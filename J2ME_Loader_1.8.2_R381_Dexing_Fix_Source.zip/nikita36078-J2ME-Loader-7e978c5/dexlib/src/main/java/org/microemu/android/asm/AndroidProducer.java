/**
 * MicroEmulator
 * Copyright (C) 2008 Bartek Teodorczyk <barteo@barteo.net>
 * Copyright (C) 2017-2018 Nikita Shakarun
 * Copyright (C) 2021-2022 Yury Kharchenko
 * <p>
 * It is licensed under the following two licenses as alternatives:
 * 1. GNU Lesser General Public License (the "LGPL") version 2.1 or any newer version
 * 2. Apache License (the "AL") Version 2.0
 * <p>
 * You may not use this file except in compliance with at least one of
 * the above two licenses.
 * <p>
 * You may obtain a copy of the LGPL at
 * http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt
 * <p>
 * You may obtain a copy of the AL at
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the LGPL or the AL for the specific language governing permissions and
 * limitations.
 *
 * @version $Id$
 */

package org.microemu.android.asm;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

public class AndroidProducer {

	public static byte[] instrument(final byte[] classData, String classFileName)
			throws IllegalArgumentException {
		ClassReader cr = new ClassReader(classData);
		if (!cr.getClassName().equals(classFileName.substring(0, classFileName.length() - 6))) {
			throw new IllegalArgumentException("Class name does not match path");
		}

		/*
		 * Older J2ME bytecode sometimes contains StackMapTable frames that do not
		 * match its class-file version. The frames are not required by DX: it
		 * reconstructs the execution stack from bytecode. Reading them with ASM
		 * can fail before DX sees the class (for example, V1_5 + F_FULL frames).
		 *
		 * ASM's COMPUTE_MAXS can also underestimate the operand stack for some
		 * preverified/obfuscated MIDlets. Keep the class's original stack limit
		 * and reserve a small safety margin for the instructions injected by
		 * AndroidMethodVisitor instead of recomputing its control-flow graph.
		 *
		 * Only the converted class bytes change. MIDlet resources, graphics,
		 * and the original JAR copied during installation remain untouched.
		 */
		ClassWriter cw = new ClassWriter(0);
		ClassVisitor stackHeadroom = new ClassVisitor(Opcodes.ASM9, cw) {
			@Override
			public MethodVisitor visitMethod(int access, String name, String desc,
			                                 String signature, String[] exceptions) {
				MethodVisitor mv = super.visitMethod(access, name, desc, signature, exceptions);
				if (mv == null) return null;
				return new MethodVisitor(Opcodes.ASM9, mv) {
					@Override
					public void visitMaxs(int maxStack, int maxLocals) {
						super.visitMaxs(Math.min(0xffff, maxStack + 8), maxLocals);
					}
				};
			}
		};
		ClassVisitor cv = new AndroidClassVisitor(stackHeadroom);
		cr.accept(cv, ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);

		return cw.toByteArray();
	}
}
