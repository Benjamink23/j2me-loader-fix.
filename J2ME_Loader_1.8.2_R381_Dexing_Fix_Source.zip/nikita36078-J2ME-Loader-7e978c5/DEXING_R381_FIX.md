# J2ME Loader 1.8.2 — R381 dexing compatibility patch

This is the **original 1.8.2 source tree (2024-08-07)** with a narrowly scoped
patch to the MIDlet bytecode converter. It does **not** replace the rendering
engine, scale images, change buttons, modify game resources, or rewrite the
input game JAR.

## Changes

1. `dexlib/.../org/microemu/android/asm/AndroidProducer.java`
   - Skip input `StackMapTable` frames, some of which are inconsistent with
     older class-file versions.
   - Preserve original method `max_stack` plus eight slots of headroom for
     the bytecode inserted by `AndroidMethodVisitor`, rather than rely on
     ASM's `COMPUTE_MAXS` in older/preverified/obfuscated classes.
2. `dexlib/.../com/android/dx/command/dexer/Main.java`
   - Use a synchronous translate-and-add path in the **default one-thread**
     mode, avoiding the asynchronous queue of class bytes and futures.
   - Preserve the original parallel behavior when the thread count is above 1.
3. `app/.../ru/woesss/j2me/installer/AppInstaller.java`
   - Pass `--no-locals --positions=none` to DX: source debugging records do
     not affect the game's behavior, sprites, controls, or resources.
   - Log conversion exceptions with Android Logcat for diagnostics.
4. `app/build.gradle`
   - Allow building a debug variant without a private release keystore.

## Reproduced technical failures

Using the exact DX sources shipped in this release, the unmodified classes
could encounter `stack: overflow` (e.g. `patch/AngelCraft.class`). Rewriting
with old stack frames intact failed at `a/a/RimReward.class` with
`Class versions V1_5 or less must use F_NEW frames`. Skipping frames *without*
preserving adequate stack headroom still failed on `a/a/ad.class`.

With the patch, an offline diagnostic compiled from the **same DX sources**
and using the Java 17 JDK's bundled ASM 8 in place of Android's Gradle-
provided ASM 9.3 completed the default DX conversion with 512 MB Java heap:

| Input | Result |
| --- | --- |
| Original r380 JAR | DEX produced |
| Original r381 Meteor Shower JAR | DEX produced; 885 classes |
| r381 Java-6 all-class variant | DEX produced |

At 384 MB the diagnostic could still exhaust the heap. On-device success
therefore depends on the Android application's actual available Java heap.
This is a **source-level fix with successful offline DX tests**, not a
signed or device-tested APK; future game revisions are not guaranteed.

## Build and install

1. Open this project with Android Studio, with its required Android SDK, NDK,
   and Gradle dependencies installed.
2. Run `./gradlew :app:assembleOpenDebug` from the project root.
3. Install the produced `openDebug` APK (the debug application ID has the
   `.debug` suffix, so it can coexist with a normal Play installation).
4. Import the **unchanged original game JAR** and test its controls, effects,
   and gameplay. If installation fails, use Logcat's `AppInstaller` tag to
   identify the underlying DX exception.

The APK has **not** been built in this workspace: the Android SDK/NDK and
Android Gradle build dependencies are unavailable here.

## License

Upstream J2ME Loader source and notices retain their original licenses.
